import React, { Component } from "react";
import { Text, View } from "react-native";

const Edit =()=>{
  return(
    <View>
      <Text>Edit</Text>
    </View>
  );
}

export default Edit;
