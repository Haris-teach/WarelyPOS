import React, { Component } from "react";
import { Text, View } from "react-native";

const OpenDrawer =()=>{
  return(
    <View>
      <Text>OpenDrawer</Text>
    </View>
  );
}

export default OpenDrawer;