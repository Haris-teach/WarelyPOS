import React, { Component } from "react";
import { Text, View } from "react-native";

const Outdoor =()=>{
  return(
    <View>
      <Text>Outdoor</Text>
    </View>
  );
}

export default Outdoor;
