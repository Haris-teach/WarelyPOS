import React  from "react";
import { Text, View } from "react-native";

const Secondfloor =()=>{
  return(
    <View>
      <Text>Secondfloor</Text>
    </View>
  );
}

export default Secondfloor;
