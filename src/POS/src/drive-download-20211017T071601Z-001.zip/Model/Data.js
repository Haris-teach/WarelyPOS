export var DATA = [

    // {
    //     key: 5,
    //     item: 'Pizza',
    //     p: 200,
    //     dis: 15.000,
    //     qty: 2,
    //     id: 0,
    // }


];