/**
 * Created by januslo on 2018/9/20.
 */
/** @format */

import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from '../../app.json';

AppRegistry.registerComponent(appName, () => App);
