const BASE_URL = "http://warly2.sapphost.com/public/api/"

export const PRODUCTS = BASE_URL + "cat_item";
export const SALE_HISTORY = BASE_URL + "history";